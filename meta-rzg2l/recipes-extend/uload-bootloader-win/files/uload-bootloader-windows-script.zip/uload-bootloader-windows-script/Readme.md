# Bootloader Programming/Flashing on U-Boot console

In order to make development more convenient, we have designed some small script programs for programming programs.
This section will introduce the relevant tools and specific steps for using these small script programs to program QSPI Flash and eMMC (Not supported yet) on U-Boot console.

## Use uload-flash_bootloader.bat to program Bootloader Images (.bin) on root filesystem (/boot/uload-bootloader) to QSPI Flash

Please following below steps:

1.Place all bootloader images (.bin) in the /boot/uload-bootloader folder on SD card (optional).

Note: The SD card must be inserted into the board before powering it on.

We've already prepared these images in the /boot/uload-bootloader folder on the SD card. If you want to change the images, replace these files in that folder.

The `/boot/uload-bootloader` folder should contain the following image files:
- bl2_bp-rzpi.bin
- fip-rzpi.bin

2.Connect debug serial (SCIF0 - TXD,RXD,GND) to Windows PC.

3.Edit **config.ini** by any editor on Windows (such as notepad) to configure the parameters according to your development environment.
Make sure your COM port when connecting debug serial is shown in Device Manager (Ports (COM&LPT)).

```
[COMMON]
COM=6
```

4.Run **uload-flash_bootloader.bat**. It will automatically launch **Tera Term** program and wait for system power up.

5.Power on the board with a 5V, Type-C interface power (to J10). It will start to flash bootloader images into QSPI flash.

Wait for the script running automatically, and no input or operation is required during this period. After completing the process, the Teraterm will disconnect and show 'disconnected' in the title bar. Then you need to power cycle the board to boot with the Bootloader images that you just flashed.
