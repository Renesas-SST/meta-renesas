# Root filesystem Programming/Flashing Procedure for RZ SBC board on Windows

This section will introduce the relevant tools and specific steps for using these small script programs to program filesystem image.

## Use flash_filesystem.bat to program Filesystem Image to SD Card

Unlike the Linux-based flashing method, where the SD card is inserted into the host PC, the Windows flashing process requires the SD card to remain inserted in the RZ/G2L-SBC board. The filesystem image is then transferred over UDP from the Windows PC to the board, enabling remote flashing.

Please following below steps:

1. Insert the SD Card into the RZ/G2L-SBC board.
Ensure that the SD card is properly inserted into the RZ/G2L-SBC board before proceeding with the flashing process.

2. Running the script

### Basic Usage

To run the script without passing any arguments, simply execute the following command:

```
.\flash_filesystem.bat
```

When no arguments are provided, the script will use the default file path for the filesystem image:

- wic file: <\path\to\your\package>\target\images\core-image-qt-rzpi.wic

Ensure that these files are present in the current directory before executing the script.

**Note: The default path is set to core-image-qt-rzpi.wic as it is the default target image.**
**You can change it based on your target image by following the below instruction.**

### Custom Usage

If you want to specify different file paths for target images, you can pass the arguments as shown below:

```
.\flash_bootloader.bat \path\to\core-image.wic
```

#### Example command

```
.\flash_filesystem.bat D:\rz-sbc\rzpi\custom_images\renesas-core-image-weston-rzpi.wic
```

The above command is an example for the root filesystem disk image `renesas-core-image-weston-rzpi.wic` when building with the target image `IMAGE=renesas-core-image-weston`. Other target images will have the same format but with names corresponding to their respective target images.

3. Connect debug serial (SCIF0 - TXD,RXD,GND) to Windows PC.

4. Connect Ethernet Port 0 (J7) on RZG2L SBC board to network on Windows PC by network cable, then power on the board and enter U-Boot console.

5. Edit **config.ini** by any editor on Windows (such as notepad) to configure the parameters according to your development environment.

Make sure your COM port when connecting debug serial is shown in Device Manager (Ports (COM&LPT)).
And an ethernet connection between the board and Windows PC.

```
[COMMON]
COM=6
IPADDR=169.254.213.175

[SYSTEM]
FILE_SYSIMG=renesas-core-image-weston-rzpi.wic
```

**Note: The IP address `IPADDR` in `config.ini` should be different (but still same subnet) from the one on Windows PC. This IP addess is used assigned to the board.**

For example: the IP address on Windows PC is `169.254.213.176`. So the IP address `IPADDR` which is assigned to the board should be `169.254.213.175`

6. Power off the board.

7. Run **flash_filesystem.bat**. It will automatically launch **Tera Term** program and wait for system power up.

8. Power on the board with a 5V, Type-C interface power (to J10). It will start to flash filesystem image into SD Card.

Wait for the script running automatically, and no input or operation is required during this period. After finishing, you can **press any key to exit the BAT script** and close the **Tera Term** program.
Then you need to power cycle the board to boot with the filesystem image that you just flashed.
